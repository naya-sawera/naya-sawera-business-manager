NAYA SAWERA HALLA V5.5 ULTIMATE BUSINESS SUITE

Upload index.html, manifest.webmanifest, sw.js, and icons/ to the GitHub repository root. Replace existing files. No Supabase migration is required.
Features: 30-day sales trend, customer lifetime purchase ledger, low-stock indicators, business insights, estimated gross profit only for matched invoice/product records, and PWA install support. Customer payment balances are not tracked.
